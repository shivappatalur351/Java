package com.Home;
import java.io.FileInputStream;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/employee", "root", "root");
			
			if(con!=null)
			{
				System.out.println("Connection successfully");
			}
			else {
				System.out.println("not connected!!!");
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		  

	}

}
