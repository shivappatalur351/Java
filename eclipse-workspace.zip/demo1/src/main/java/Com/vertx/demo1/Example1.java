package Com.vertx.demo1;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.http.HttpServer;

public class Example1  extends AbstractVerticle {

		 private HttpServer server;

		 public void start(Promise<Void> startPromise) {
		   server = vertx.createHttpServer().requestHandler(req -> {
		     req.response()
		       .putHeader("content-type", "text/plain")
		       .end("Hello from Vert.x!");
		     });

		   // Now bind the server:
		   server.listen(8080, res -> {
		     if (res.succeeded()) {
		       startPromise.complete();
		     } else {
		       startPromise.fail(res.cause());
		     }
		   });
		 }
}
