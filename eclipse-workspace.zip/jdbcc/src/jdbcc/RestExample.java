package jdbcc;

public class RestExample {
	
	router.post("/

}
