You can also write your Vert.x integration tests as Groovy, JavaScript, Python or Ruby scripts, and use a
familiar JUnit-like Assert API in your tests.

The sub-directories here have some examples.