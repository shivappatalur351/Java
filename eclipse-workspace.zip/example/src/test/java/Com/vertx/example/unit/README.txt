Put your unit tests in here.

Unit tests talk directly to your project test classes and aren't run inside the Vert.x container.