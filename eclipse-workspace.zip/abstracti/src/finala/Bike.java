package finala;

public class Bike {
	
	final void run() {
		System.out.println("Hero");
	}

}
