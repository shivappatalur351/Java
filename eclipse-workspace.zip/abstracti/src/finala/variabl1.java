package finala;

class variabl1 {

	final int a=10;
	
	 void run()
	{
		a=100;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
variabl1 v=new variabl1();
v.run();

	}

}
