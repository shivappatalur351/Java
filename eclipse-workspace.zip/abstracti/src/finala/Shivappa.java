package finala;

public class Shivappa extends Shiv {

	void run() {
		System.out.println("Its working fine");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Shivappa s=new Shivappa();
s.run();
	}

}
