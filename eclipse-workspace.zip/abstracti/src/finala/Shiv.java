package finala;

class Shiv {
	
	void run() {
		System.out.println("final classs");
	}

}
