package finala;

public class Bikss extends Bike {
void run() {
	System.out.println("Running fine");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Bikss b=new bikss();
		b.run();
	}

}
