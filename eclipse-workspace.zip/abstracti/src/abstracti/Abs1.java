package abstracti;

abstract class Abs1 {

	public abstract void Person();
	
	public void sleep() {
		System.out.println("Everyday sleep at 10pm");
	}
	
	
}
