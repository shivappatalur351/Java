package abstracti;

public class AbsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Abs2  ab=new Abs2();
		ab.Person();
		ab.sleep();
	}

}
