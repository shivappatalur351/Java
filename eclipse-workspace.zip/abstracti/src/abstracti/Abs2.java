package abstracti;

public class Abs2 extends Abs1{
	
	public void Person()
	{
		System.out.println("Three times eated on a day");
	}

}
