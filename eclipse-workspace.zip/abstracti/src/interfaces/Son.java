package com.interfaces;

public class Son implements Family,Relatives {

	public void address() {
		System.out.println("Son Born Place is Hubli");
	}
	public void addres() {
		System.out.println("Welcome Hubli");
	}
}
