package com.interfaces;

public class Father implements Family,Relatives {

	public void address() {
		System.out.println("Father Born place is Dharwad");
	}
	public void addres() {
		System.out.println("WelCome To Dharwad");
	}
}
