package com.interfaces;

public class Mother implements Family,Relatives{

	public void address()
	{
		System.out.println("Mother Born Place Gadag");
	}
	public void addres()
	{
		System.out.println("Welcome Gadag");
	}
}
