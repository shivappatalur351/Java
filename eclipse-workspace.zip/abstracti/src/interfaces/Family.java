package com.interfaces;

public interface Family extends Relatives {
	
	public void address();

}
