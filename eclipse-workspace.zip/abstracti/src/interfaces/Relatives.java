package com.interfaces;

public interface Relatives {
	
	public void addres();

}
