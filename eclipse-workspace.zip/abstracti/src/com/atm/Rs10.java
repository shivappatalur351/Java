package com.atm;

public class Rs10 extends Rs {

	Rs10(int i){
		this.rs=i;
	}
	void message(int amount) {
		if(amount>=10) {
			System.out.printf("10Rs Notes= "+amount/10);
			amount=amount-10*(amount/10);
		}
		nextRs.message(amount);
		
	}
}
