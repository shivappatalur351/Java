package com.atm;

public class Rs50 extends Rs {

	Rs50(int i){
		this.rs=i;
	}
	void message(int amount) {
		if(amount>=50) {
			System.out.println("50Rs Notes= "+amount/50);
			amount=amount-50*(amount/50);
		}
		nextRs.message(amount);
		
	}
}
