package com.atm;

abstract class Rs {
int rs;
abstract void message(int amount);
Rs nextRs;
}
