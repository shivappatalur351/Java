package com.atm;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
Rs rs100=new Rs100(100);
Rs rs50=new Rs50(50);
Rs rs10=new Rs10(10);


rs100.nextRs=rs50;
rs50.nextRs=rs10;
rs100.message(180);
	}
catch(NullPointerException e) {
	System.out.println();
}
	}
}
