package com.atm;

public class Rs100 extends Rs{
	
	Rs100(int i){
		this.rs=i;
	}
	void message(int amount) {
		if(amount>=100) {
			System.out.println("100Rs Notes= "+amount/100);//1100/100=11
			amount=amount-100*(amount/100);//1180=1180-100*11;
		}
		nextRs.message(amount);
		
	}

}
