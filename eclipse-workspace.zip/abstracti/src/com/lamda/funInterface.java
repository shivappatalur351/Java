package com.lamda;

public interface funInterface {
public void draw();
}
