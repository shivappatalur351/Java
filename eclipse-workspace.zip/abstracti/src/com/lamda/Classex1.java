package com.lamda;

public class Classex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Interfaceex1 add=(a,b)->(a+b);
		System.out.println(add.Addable(10, 20));

}
}