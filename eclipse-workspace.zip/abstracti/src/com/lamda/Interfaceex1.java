package com.lamda;

import java.io.InputStream;

@FunctionalInterface 
public interface Interfaceex1 {

	int Addable(int a,int b);

	}
