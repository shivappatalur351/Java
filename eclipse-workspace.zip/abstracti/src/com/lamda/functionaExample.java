package com.lamda;

public class functionaExample {
public static void main(String[] args) {
	
	int width=10;
	
	funInterface s2=()->{
		System.out.println("width "+width);
	};
	s2.draw();
}
}
