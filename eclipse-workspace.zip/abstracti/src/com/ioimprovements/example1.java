package com.ioimprovements;

import java.io.IOException;
import java.io.InputStreamReader;

public class example1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		InputStreamReader inp=new InputStreamReader(System.in);
		
		char c;
		System.out.println("Enter a character:");
		do {
			
			c=(char) inp.read();
			System.out.println(c);
		}while(c!='0');
	}

}
