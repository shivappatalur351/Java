package com.ioimprovements;

import java.io.*;

public class Example2 {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		try {
			
		
FileInputStream inp=new FileInputStream("one.txt");
FileOutputStream otp=new FileOutputStream("three.txt");

int temp;
while((temp=inp.read())!=-1) {
	otp.write((byte)temp);
	
}
System.out.println("copied successfully!!!");
		}
		catch(FileNotFoundException e) {
			System.out.println("the file is not there"+e);
		}
	}

}

