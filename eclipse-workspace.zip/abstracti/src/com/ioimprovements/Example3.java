package com.ioimprovements;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.stream.Stream;

public class Example3 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
Path path=Paths.get("three.txt");

try(Stream<String> lines=Files.lines(path)) {
	Optional<String> optional=lines.filter(s->s.contains("java")).findFirst();
	if(optional.isPresent()) {
		System.out.println(optional.get());
	}
	else {
		System.out.println("No data found");
}}
catch(Exception e)
{
	System.out.println(e);
}

	}

}
