package com.foreach;

import java.util.*;

public class example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> teams=new ArrayList<String>();
		teams.add("Shivu");
		teams.add("vilas");
		teams.add("naveen");
		teams.add("chandana");
		
		System.out.println("Iterating by lambda expressions");
		teams.forEach(gamelist->System.out.println(gamelist));
		
		
	}

}
