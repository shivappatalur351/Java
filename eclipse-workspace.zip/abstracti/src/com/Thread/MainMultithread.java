package com.Thread;

//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;

public class MainMultithread {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		//int corecount=Runtime.getRuntime().availableProcessors();
		//ExecutorService service=Executors.newFixedThreadPool(corecount);
		Multithreading mt=new Multithreading();
		Multithreading mt1=new Multithreading();
		mt.start();
		Thread.sleep(1000);
		mt1.start();
	}
}

