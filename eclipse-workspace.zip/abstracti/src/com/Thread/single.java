package com.Thread;

public class single {
public void run() {
	System.out.println("Thread start");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
single s=new single();
s.run();
	}

}
