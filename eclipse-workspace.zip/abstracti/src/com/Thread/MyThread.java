package com.Thread;

public class MyThread implements Runnable {

}
