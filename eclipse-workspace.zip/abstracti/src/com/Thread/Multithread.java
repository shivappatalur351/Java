package com.Thread;

public class Multithread implements Runnable {
String task;
Multithread(String task){
	this.task=task;
}
public void run() {
	for(int i=0;i<=4;i++) {
		System.out.println(task+":"+i);
		try {
			Thread.sleep(1000);
		}
	catch(InterruptedException e) {
		e.printStackTrace();
	}
}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Thread nThread=Thread.currentThread();
System.out.println(nThread);

Multithread mt=new Multithread("shivu");
Thread t1=new Thread(mt);
Thread t2=new Thread(mt);
Thread t3=new Thread(mt);
t1.start();
t2.start();
t3.start();
int count=Thread.activeCount();
System.out.println("no of active threads"+count);
	}

	}
