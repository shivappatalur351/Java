package com.filehandle;

import java.io.*;
import java.util.*;

public class FileReaderExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	File f=new File("one.txt");
	Scanner  s=new  Scanner(f);
	while(s.hasNextLine()) {
		String data=s.nextLine();
		System.out.println(data);
	}
	
}
catch(FileNotFoundException e) {
	System.out.println("File not found!!!!");
}
		
	}

}
