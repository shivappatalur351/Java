package com.filehandle;

import java.io.*;

public class ReadExample {

	public static void main(String[] args) throws IOException {
		
		File f=new File("two.txt");
		try {
if(f.createNewFile()) {
	System.out.println("File Created successfully");
}
else {
	System.out.println("File already exist!!!");
	}
		}
		catch(IOException e) {
			System.out.println(e);
		}
		
		if(f.exists()) {
			System.out.println("the name of the file "+f.getName());
			
			System.out.println("the name of the file "+f.getAbsolutePath());
			
			System.out.println("the name of the file "+f.canWrite());
			
			System.out.println("the name of the file "+f.canRead());

			System.out.println("the name of the file "+f.length());
		}
}
}
