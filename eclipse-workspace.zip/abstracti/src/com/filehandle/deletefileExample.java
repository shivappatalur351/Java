package com.filehandle;
import java.io.*;
public class deletefileExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File f=new File("two.txt");
if(f.delete()) {
	System.out.println("the deleted file successfully");
}
else {
	System.out.println("File  Not found!!!");
}
	}

}
