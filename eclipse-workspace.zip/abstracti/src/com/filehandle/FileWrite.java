package com.filehandle;

import java.io.*;

public class FileWrite {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
		FileWriter f=new FileWriter("one.txt");
		
		f.write("Welcome to file handling concepts in java");
		f.close();
		System.out.println("The content stored  successfully!!!");
	}
catch(IOException e) {
	System.out.println("Exception occured");
}
	}

}
