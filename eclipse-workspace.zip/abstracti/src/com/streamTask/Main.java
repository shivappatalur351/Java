package com.streamTask;
import java.util.*;
import java.util.stream.Collectors;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Event> eventlist=new ArrayList<Event>();
		
	Scanner sc=new Scanner(System.in);
	String line;
	String[] splt;
	String value;
	
	
	System.out.println("Enter the number of Events");
	int num=sc.nextInt();
	
	if(num>0) {
	String temp=sc.nextLine();
	System.out.println("Enter Event name,Event Type,Organaizer Name");
	for(int i=1;i<=num;i++) {
		
	line=sc.nextLine();
	splt=line.split(",");
	eventlist.add(new Event(splt[0],splt[1],splt[2]));
	}
	
	System.out.println("Filter:");
	System.out.println("1)Using Event name");
	System.out.println("2)Using Event type");
	System.out.println("3)Using Organizer name");
	
	System.out.println("Enter choice:");
	int m=sc.nextInt();
	if(m>0 && m<4)
	{
	
	switch(m) {
	case 1:
			System.out.println("Enter Event name:");
			value=sc.next();
		
			eventlist.stream()
							.filter(Event->Event.getEventName().equals(value))
							.forEach(Event->System.out.println(Event.getEventName()+"|"+Event.getEventType()+"|"+Event.getOrganizer()));


						break;
	case 2:
			System.out.println("Enter event type:");
			String value1=sc.next();
			
			eventlist.stream()
						.filter(Event->Event.getEventType().equals(value1))
						.forEach(Event->System.out.println(Event.getEventName()+"|"+Event.getEventType()+"|"+Event.getOrganizer()));

						break;
	case 3:
		System.out.println("Enter organizer name:");
		String value2=sc.next();
		
			eventlist.stream()
						.filter(Event->Event.getOrganizer().equals(value2))
						.forEach(Event->System.out.println(Event.getEventName()+"|"+Event.getEventType()+"|"+Event.getOrganizer()));

						break;
	default:System.out.println("Invalid Choice!!!");
	}
	}
	else {
		System.out.println("Invalid  Input");
	}
	}
	
	else {
		System.out.println("Invalid number!!!");
	}
	}

	
}


