package com.streamTask;

public class Event {
private String eventName;
private String eventType;
private String organizer;

public Event() {
	super();
}

public Event(String eventName, String eventType, String organizer) {
	super();
	this.eventName = eventName;
	this.eventType = eventType;
	this.organizer = organizer;
}

public String getEventName() {
	return eventName;
}

public void setEventName(String eventName) {
	this.eventName = eventName;
}

public String getEventType() {
	return eventType;
}

public void setEventType(String eventType) {
	this.eventType = eventType;
}

public String getOrganizer() {
	return organizer;
}

public void setOrganizer(String organizer) {
	this.organizer = organizer;
}

public String trim() {
	// TODO Auto-generated method stub
	return null;
}
 



}
