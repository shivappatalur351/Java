package com.dateTime;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.Month;

public class DateandTime {
	
	

	   public static void main(String args[]) {
	   LocalDateTime current=LocalDateTime.now();
	   LocalDate date=LocalDate.now();
	     System.out.println("The current time is:"+current);
	   System.out.println("The current date is"+date);
	   
	   LocalDateTime date2=current.withDayOfMonth(6).withYear(2022);
	   System.out.println("specific date "+date2);
	   LocalTime local=LocalTime.parse("20:15:30");
	   System.out.println(" "+local);
	   }

}
