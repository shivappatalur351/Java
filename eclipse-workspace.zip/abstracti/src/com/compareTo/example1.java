package com.compareTo;

public class example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="shivu";
String str2="shish";
int diff=str.compareTo(str2);
System.out.println(diff);
	}

}
