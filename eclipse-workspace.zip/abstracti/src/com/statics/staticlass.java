package com.statics;

public class staticlass   {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		staticinterface.show("welcome");
	}

}
