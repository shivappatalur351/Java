package com.statics;

public interface staticinterface {

	static void show(String msg) {
		System.out.println(msg);
	}
}
