package com.EncodeAndDecode;
import java.util.Base64;
public class Example1 {
  
	    public static void main(String[] args) {  
	        // Getting encoder  
	        Base64.Encoder encoder = Base64.getEncoder();  
	        // Creating byte array  
	        byte Arr[] = {1,2};  
	        // encoding byte array  
	        byte Arr2[] = encoder.encode(byte Arr) ;
	        System.out.println("Encoded byte array: "+byteArr2);  
	        byte Arr3[] = new byte[5];                // Make sure it has enough size to store copied bytes  
	        intx = encoder.encode(byteArr,byteArr3);    // Returns number of bytes written  
	        System.out.println("Encoded byte array written to another array: "+byteArr3);  
	        System.out.println("Number of bytes written: "+x);  
	      
	        // Encoding string  
	        String str = encoder.encodeToString("JavaTpoint".getBytes());  
	        System.out.println("Encoded string: "+str);  
	        // Getting decoder  
	        Base64.Decoder decoder = Base64.getDecoder();  
	        // Decoding string  
	        String dStr = new String(decoder.decode(str));  
	        System.out.println("Decoded string: "+dStr);  
	    
	    
	    String shivu=Base64.getEncoder().encodeToString(Arr3);
	    }  
	}  
}
