package com.EncodeAndDecode;

import java.util.Base64;

public class Example2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="jdbc:mysql://localhost:3306/phoneinformation";
	
		String base=Base64.getEncoder().encodeToString(str.getBytes());
		System.out.println(base);
		
		
		byte str1[]=Base64.getDecoder().decode(base);
		String result=new String(str1);
		
		System.out.println(result);
	}

}
