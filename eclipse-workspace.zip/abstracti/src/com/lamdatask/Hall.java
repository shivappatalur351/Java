package com.lamdatask;

import java.util.Collections;
import java.util.Comparator;

public class Hall {
private String name;
private Double costPerDay;
private String owner;


public Hall() {
	super();
}



public Hall(String name, Double costPerDay, String owner) {
	super();
	this.name = name;
	this.costPerDay = costPerDay;
	this.owner = owner;
}



public String getName() {
	return name;
}



public void setName(String name) {
	this.name = name;
}



public Double getCostPerDay() {
	return costPerDay;
}



public void setCostPerDay(Double costPerDay) {
	this.costPerDay = costPerDay;
}



public String getOwner() {
	return owner;
}



public void setOwner(String owner) {
	this.owner = owner;
}



@Override
public String toString() {
	return   name + "     "+ costPerDay + "	   " + owner ;
}
/*
Collections.sort(result,new Comparator<Hall>() {
	@Override
	public int compare(Hall o1,Hall o2) {
		return o1.getOwner().compareTo(o2.getOwner());
	}
});*/


}
