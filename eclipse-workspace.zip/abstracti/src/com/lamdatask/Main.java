package com.lamdatask;
import  java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Hall>result=new ArrayList<Hall>();
	
		Scanner s=new Scanner(System.in);
		String[] spt;
		String temp;

			System.out.println("Enter the number of halls");
			int num=s.nextInt();
			
			String tem=s.nextLine();
			
			
			System.out.println("Enter the number of data"+1);
			for(int i=1;i<=num;i++) {
				
				temp=s.nextLine();
				spt=temp.split(",");
			 
			
			result.add(new Hall(spt[0],Double.parseDouble(spt[1]),spt[2]));
			
			}
	//int diff="girish".compareTo("ghivu");
	//System.out.println(diff);
	result.sort((o1,o2)->o2.getOwner().compareTo(o1.getOwner()));
	System.out.format("%-15s %-10s %s\n","Name","Cost","Owner");
	result.forEach((Hall)->System.out.println(Hall));
	
	}
}	


