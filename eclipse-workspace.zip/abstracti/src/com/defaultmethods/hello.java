package com.defaultmethods;

public interface hello {
	
	default void say() {
		System.out.println("Welcome to default methods");
	}
	public void show(String msg);

}
