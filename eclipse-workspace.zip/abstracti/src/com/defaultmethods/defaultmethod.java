package com.defaultmethods;

public class defaultmethod implements hello {

	public void show(String msg) {
		// TODO Auto-generated method stub
		System.out.println(msg);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
defaultmethod dm=new defaultmethod();
dm.say();
dm.show("its working fine");
	}
	
}
