package com.stream;

import java.util.*;
import java.util.stream.Collectors;

public class Examplemain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<product> productlist=new ArrayList<product>();
productlist.add(new product(1,"hp",20000f));
productlist.add(new product(2,"dell",30000f));
productlist.add(new product(3,"lenova",40000f));
productlist.add(new product(4,"acer",40000f));

productlist.stream()
					.filter(product->product.price == 40000)
					.forEach(product->System.out.println(product.name));
System.out.println();
productlist.stream()
			.sorted((e1, e2) -> e1.getName().compareTo(e2.getName()))
			.collect(Collectors.toList())
			.forEach(product->System.out.println(product.id+" "+product.name+" "+product.price));
	}
}
