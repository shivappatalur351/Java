package com.stream;
import java.util.*;
public class anymatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> anymatchlist=new ArrayList<String>();
		anymatchlist.add("shivu");
		anymatchlist.add("naveen");
		anymatchlist.add("vilas");
		anymatchlist.add("chandana");
		
		
		boolean result=anymatchlist.stream().anyMatch(s->Character.isUpperCase(s.charAt(0)));
		System.out.println(result);
		
		
	}

}
