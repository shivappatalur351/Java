package com.practice;

import java.util.List;
import java.util.stream.Collectors;

public class Event {
private String eventName;
private String eventType;
private String organizer;

public Event() {
	super();
}

public Event(String eventName, String eventType, String organizer) {
	super();
	this.eventName = eventName;
	this.eventType = eventType;
	this.organizer = organizer;
}

public String getEventName() {
	return eventName;
}

public void setEventName(String eventName) {
	this.eventName = eventName;
}

public String getEventType() {
	return eventType;
}

public void setEventType(String eventType) {
	this.eventType = eventType;
}

public String getOrganizer() {
	return organizer;
}

public void setOrganizer(String organizer) {
	this.organizer = organizer;
}

public static void filterEvents(List<Event> eventlist, String value,int id) {
	// TODO Auto-generated method stub
if(id==1) {
eventlist.stream()
						.filter(Event->Event.getEventName().contains(value))
						.forEach(Event->System.out.println(Event.getEventName()+"|"+Event.getEventType()+"|"+Event.getOrganizer()));
}
else if(id==2) {
eventlist.stream()
						.filter(Event->Event.getEventType().contains(value))
						.forEach(Event->System.out.println(Event.getEventName()+"|"+Event.getEventType()+"|"+Event.getOrganizer()));
}
else {
eventlist.stream()
						.filter(Event->Event.getOrganizer().contains(value))
						.forEach(Event->System.out.println(Event.getEventName()+"|"+Event.getEventType()+"|"+Event.getOrganizer()));
}
}	 
}


