package com.practice;

import java.util.*;
public class Main {

	public static void main(String[] args)throws InputMismatchException {
		// TODO Auto-generated method stub
		List<Event> eventlist=new ArrayList<Event>();
		Main m=new Main();
		

	Scanner sc=new Scanner(System.in);
	String line;
	String[] splt;
	String value;
	try {
	
	System.out.println("Enter the number of Events");
	int num=sc.nextInt();
	
	if(num>0) {
	String temp=sc.nextLine();
	
	System.out.println("Enter Event name,Event Type,Organaizer Name");
	for(int i=1;i<=num;i++) {
		
	line=sc.nextLine();
	splt=line.split(",");
	eventlist.add(new Event(splt[0],splt[1],splt[2]));
	}
	
	
	System.out.println("Filter:");
	System.out.printf("1)Using Event name\n"+"2)Using Event type\n"+"3)Using Organizer Name\n"+"Enter choice:\n");
	
	int id=sc.nextInt();
	if(id>0 && id<4)
	{
	
	switch(id) {
	case 1:
		
			System.out.println("Enter Event name:");
			value=sc.next();
			Event.filterEvents(eventlist, value,id);
	
				break;
	case 2:
			System.out.println("Enter event type:");
			String value1=sc.next();
			 	Event.filterEvents(eventlist, value1,id);
				break;
	case 3:
			System.out.println("Enter organizer name:");
			String value2=sc.next();
				 Event.filterEvents(eventlist,value2,id);	
				break;
	}
	}
	else {
		System.out.println("Invalid Input");//m input greater than 3
		
	}
	}
	
	else {
		System.out.println("Invalid number!!!");//n input less than 1
	}
	
	}
	catch(Exception e) {
	System.out.println("Please Enter Number!!! ");
	}

}

	
}
