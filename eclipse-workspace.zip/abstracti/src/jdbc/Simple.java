package jdbc;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
public class Simple {
	

	
		public static void main(String[] args)throws ClassNotFoundException,IOException {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/employee", "root", "root");
				
				if(con!=null)
				{
					System.out.println("Connection successfully");
				}
				else {
					System.out.println("not connected!!!");
				}
			}
			catch(Exception e) {
				System.out.println(e);
			}
			
		}
	
}
