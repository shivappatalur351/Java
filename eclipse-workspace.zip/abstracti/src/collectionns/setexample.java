package com.collectionns;
import java.io.*;   
import java.util.*;   
  
public class setexample {
	
	    public static void main(String args[])   
	    {   
	        Set<Integer> data = new LinkedHashSet<Integer>();   
	        data.add(31);   
	        data.add(21);   
	        data.add(41);   
	        data.add(11);   
	        data.add(61);   
	        data.add(51);
	        data.add(11);
	        data.add(12);
	        System.out.println(""+data);
	        System.out.println("data is Available " + data.contains(31));  
	        System.out.println("data: " + data.hashCode());
	        System.out.println("clear data " +data.isEmpty());
	    
	        System.out.println("clear data  " +data.size());
	    }   
	    
	
}
