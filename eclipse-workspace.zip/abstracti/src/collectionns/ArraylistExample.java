package com.collectionns;

import java.util.*;

public class ArraylistExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> al=new ArrayList<String>();
		al.add("Shivappa");
		al.add("sameena");
		al.add("hemanta");
		
		
		Iterator itr=al.iterator();
		
		while(itr.hasNext()) { 
			System.out.println(itr.next());
		
		}
		//al.remove(0);
		//System.out.println(""+al);
		
		//al.remove("sameena");
		//System.out.println(""+al);
		
		ArrayList<String> al2=new ArrayList<String>();
		al2.add("Shivakumar");
		al2.add("Jaffar");
		al2.add("Sushma");
		al2.add("hemanta");
		//al.addAll(al2);
		
		
		System.out.println(""+al2);
		
		boolean st=al2.contains("Sushma");
	System.out.println(""+st);
	
	//it shows common value
	al.retainAll(al2);
	System.out.println(""+al);
		
	al2.set(3,"Java");
	System.out.println(al2);
	}

	
}
