package Tasks;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PriceAndBookingTimeComparator implements Comparator<TicketBooking>{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
Map<String,TicketBooking> mp = new HashMap<>();
System.out.println("Enter the bookings");
int num=s.nextInt();


for(int i=0;i<num;i++){
	System.out.println("The Bookings Details"+(i+1));
	String stageEventShow =s.next();
	String bookingTime	=s.next();
	String seatNumber =s.next();
	Double price=s.nextDouble();
	 TicketBooking tkt = new TicketBooking(stageEventShow,bookingTime,seatNumber,price);
     mp.put(tkt.getStageEventShow(), tkt);
     
}

	}

	@Override
	public int compare(TicketBooking o1, TicketBooking o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
