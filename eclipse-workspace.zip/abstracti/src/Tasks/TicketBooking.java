package Tasks;

public class TicketBooking {
	private String stageEventShow;
	private String bookingTime;
	private String seatnumber;
	private Double price;
	
	public TicketBooking() {
		super();
	}
	public TicketBooking(String stageEventShow, String bookingTime, String seatnumber, Double price) {
		super();
		this.stageEventShow = stageEventShow;
		this.bookingTime = bookingTime;
		this.seatnumber = seatnumber;
		this.price = price;
	}
	public String getStageEventShow() {
		return stageEventShow;
	}
	public void setStageEventShow(String stageEventShow) {
		this.stageEventShow = stageEventShow;
	}
	public String getBookingTime() {
		return bookingTime;
	}
	public void setBookingTime(String bookingTime) {
		this.bookingTime = bookingTime;
	}
	public String getSeatnumber() {
		return seatnumber;
	}
	public void setSeatnumber(String seatnumber) {
		this.seatnumber = seatnumber;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "TicketBooking [stageEventShow=" + stageEventShow + ", bookingTime=" + bookingTime + ", seatnumber="
				+ seatnumber + ", price=" + price + "]";
	}
	
	public int compare(TicketBooking o1, TicketBooking o2) {
		// TODO Auto-generated method stub
		if(o1.price<o2.price) return -1;
		else if(o1.price > o2.price) return 1;
		
		else return 1;
	}
	

}
