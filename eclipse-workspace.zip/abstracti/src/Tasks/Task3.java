package Tasks;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Task3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,Airport> mp = new HashMap<>();
        Scanner inpu = new Scanner(System.in);
        System.out.println("Enter the number of airports");
        int n = inpu.nextInt();
        inpu.nextLine();
        for(int i=0;i<n;i++) {
            System.out.println("Enter the details of the airport "+(i+1));
            String airport_code = inpu.nextLine();
            String airport_name = inpu.nextLine();
            String airport_city = inpu.nextLine();
            Airport air = new Airport(airport_code,airport_name,airport_city);
            mp.put(air.getIataAirportCode(), air);
            
        }
        System.out.println("Airport Details");
        for (Map.Entry m : mp.entrySet()) {
            System.out.println( m.getValue());
        }
        

	}

}
