package Tasks;

import java.util.ArrayList;
import java.util.*;

public class Task1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

int k=0;
int l=0;

		ArrayList<String> arr=new ArrayList<String>();
		ArrayList<String> arr1=new ArrayList<String>();
		ArrayList<String> list=new ArrayList<String>();
		Set<String> set=new HashSet<String>();
		
		Scanner sc = new Scanner(System.in);
		
		 System.out.println("Enter the number of passengers in First friday flight from Chennai to Coimbatore");
		
        int num=sc.nextInt();
        System.out.println("Enter passenger Names:");
		for(int i=0;i<num;i++) {
			
			arr.add(sc.next());
		}
	

System.out.println("Enter the number of passengers in Second friday flight from Chennai to Coimbatore");
		
		 k=sc.nextInt();
		 
		 System.out.println("Enter the passengers Names");  
        
		for(int i=0;i<k;i++) {
		
			arr1.add(sc.next());
		}

System.out.println("Enter the number of passengers in third friday flight from Chennai to Coimbatore");
		
		 l=sc.nextInt();
		
		 System.out.println("Enter the passengers Names");    
		for(int i=0;i<l;i++) {
		
			list.add(sc.next());
		}
	
		ArrayList<String> st=new ArrayList<String>();
		ArrayList<String> st1=new ArrayList<String>(arr);
		
		System.out.println("The discount offered:");
		
		arr.retainAll(arr1);//workking a->b
		st.addAll(arr);
	
		arr1.retainAll(list);//working b->c
		st.addAll(arr1);
		
		st1.retainAll(list);// working a->c||c->a
		st.addAll(st1);
						
				
		set.addAll(st);
		System.out.println(set);;
		
	}

}
