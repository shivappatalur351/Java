package Tasks;

import java.util.*;



public class Task2 implements Comparable<Card> {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Map<Character,Card> map = new TreeMap<>();
        List<Character> list = new ArrayList<>();
        int count = 0;
        boolean flag;

        do {
            Card c  = new Card();
            System.out.println("Enter a card: ");
            c.setSymbol(sc.nextLine().trim().charAt(0));
            c.setNumber(sc.nextInt());
            sc.nextLine();
    if(!map.containsKey(c.symbol))
                 map.put(c.symbol,c);
            count++;
            list.add(c.symbol);
            if(list.contains('a') && list.contains('b') && list.contains('c') && list.contains('d')){
                flag =false;
            }else {
                flag = true;
            }

        }while(flag);


        System.out.println();
        System.out.println("Four symbols gathered in "+count+" Cards.");
        System.out.println("Cards in Set are: ");

        for(char ch:map.keySet()) {
            System.out.println(ch+" "+map.get(ch).getNumber());
        }
        sc.close();
    }

	@Override
	public int compareTo(Card o) {
		// TODO Auto-generated method stub
		return 0;
	}
		
	}
