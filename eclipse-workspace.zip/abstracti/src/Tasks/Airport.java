package Tasks;

public class Airport {
	private String AirportCode;
    private String name;
    private String city;
	public String getIataAirportCode() {
		return AirportCode;
	}
	public void setAirportCode(String AirportCode) {
		this.AirportCode = AirportCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Airport(String AirportCode, String name, String city) {
		super();
		this.AirportCode = AirportCode;
		this.name = name;
		this.city = city;
	}
	
	    @Override
		public String toString() {
			//return "Airport [AirportCode=" + AirportCode + ", name=" + name + ", city=" + city + "]";
		return AirportCode+"--"+name+"--"+city;
	    }
	    


}
