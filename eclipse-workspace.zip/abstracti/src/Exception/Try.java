package Exception;

public class Try {
	public static void main(String args[]) {
		int a=0;
		int b=10;
	try {
		int c=b/a;
	}
	catch(ArithmeticException e) {
		System.out.println("Divide By an Error");
	}
	finally {
	System.out.println("Thank you");
		}
}
}