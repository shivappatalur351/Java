package Exception;

public class example {

}
