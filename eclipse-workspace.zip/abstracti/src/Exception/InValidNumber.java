package Exception;

public class InValidNumber extends Exception {
	String msg;
	
	public InValidNumber(String msg)
	{
		super(msg);
	}

}
