package com.shivappa.Simple.Service;

import java.util.ArrayList;
import java.util.List;

import com.shivappa.Simple.model.Message;

public class MessageService {
	public List<Message> getAllMessage(){
		Message m1=new Message(1,"Hello World","Shivappa");
		Message m2=new Message(2,"thbs","bangalore");
List<Message> list=new ArrayList();
list.add(m1);
list.add(m2);

		return list ;
	}

}
