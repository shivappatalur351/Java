package com.shivappa.Simple.resource;

import java.util.List;

import com.shivappa.Simple.Service.MessageService;
import com.shivappa.Simple.model.*;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/messages")
public class Example {
	MessageService messageservice = new MessageService();
	@GET
	@Produces(MediaType.APPLICATION_XML)
public List<Message> getMessage() {
	return messageservice.getAllMessage();
}
}
